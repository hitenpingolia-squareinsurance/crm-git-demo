import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from "@angular/forms";
import { ApiService } from "src/app/providers/api.service";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "src/environments/environment";
import { DataTableDirective } from "angular-datatables";
import { ActivatedRoute } from '@angular/router';


class ColumnsObj {
  SrNo: string;
  Id: any;
  LobType: any;
  Name: any;
  Mobile: any;
  Email: any;
  State: any;
  City: any;
  Pincode: any;
  Source: any;
  Campaign: any;
  StartDate: any;
  ExpiryDate: any;
  Insurer: any;
  Premium: any;
  FamilyGroup: any;
  MotorType: any;
  RegistrationNo: any;
  Make: any;
  Model: any;
  Variant: any;
  PrevPolicyInsurer: any;
  Claim: any;
  EmployeeName: any;
  EmployeeID: any;
  Status: any;
  Remarks: any;

  UploadedBy: any;
  AssignerName: any;
  AssignerEmployeeId: any;
}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
  FilterPolicyData: any[];
}


@Component({
  selector: 'app-view-data-list',
  templateUrl: './view-data-list.component.html',
  styleUrls: ['./view-data-list.component.css']
})
export class ViewDataListComponent implements OnInit {
  @ViewChild(DataTableDirective, { static: false }) datatableElement: DataTableDirective;


  uniqueId: string = '';
  searchForm: FormGroup;
  DataLeadForm: FormGroup;
  dtOptions: DataTables.Settings = {};
  dataAr: ColumnsObj[];

  currentEditId: string = '';

  showMotorFields: boolean = false;
  showHealthFields: boolean = false;

  lobTypesData: any[] = [];
  MotorTypesData: any[] = [];
  ClaimData: any[] = [];
  StausData: any[] = [];

  SubmitDataLeadForm: boolean = false;


  dropdownMultiSelectSettingsType: any;

  modalMode: 'add' | 'edit' = 'add';

  hasAccess: boolean = true;
  errorMessage: string = "";


  constructor(private formBuilder: FormBuilder, private api: ApiService, private http: HttpClient, private route: ActivatedRoute) {

    this.loadDropdownData();
    

    this.searchForm = this.formBuilder.group({
      SearchValue: [""],
      StatusFilter: [[]],
      LobFilter: [[]]
    });

    this.DataLeadForm = this.formBuilder.group({
      LobType: [[], Validators.required],
      Name: ['', Validators.required],
      Mobile: ['', Validators.required],
      Email: [''],
      State: [''],
      City: [''],
      Pincode: [''],
      Source: [''],
      Campaign: [''],
      StartDate: [''],
      ExpiryDate: ['', Validators.required],
      Insurer: [''],
      Premium: [''],
      FamilyGroup: [''],
      MotorType: [[]],
      RegistrationNo: [''],
      Make: [''],
      Model: [''],
      Variant: [''],
      PrevPolicyInsurer: [''],
      Claim: [[]]
    });


    this.dropdownMultiSelectSettingsType = {
      singleSelection: true,
      idField: "Id",
      textField: "Name",
      itemsShowLimit: 2,
      enableCheckAll: false,
      allowSearchFilter: true,
    };

   }

  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      this.uniqueId = params.get('id') || '';
      this.Get(); 
      this.Reload();
    });
    
  }

  ClearSearch() {
    this.searchForm.reset({
      SearchValue: '',
      StatusFilter: '', // Reset status filter too
      LobFilter: ''
    });
    this.Get();
    this.ResetDT();
  }

  Reload() {
    this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
      var pageinfo = dtInstance.page.info().page;
      dtInstance.page(pageinfo).draw(false);
    });
  }

  ResetDT() {
    this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.search("").column(0).search("").draw();
    });
  }

  SearchData() {
    const fields = this.searchForm.value;
    this.dataAr = [];

    const lobFilterString = fields.LobFilter 
    ? fields.LobFilter.map((item: any) => item.Name).join(',') 
    : '';

    const StatusFilterString = fields.StatusFilter 
    ? fields.StatusFilter.map((item: any) => item.Id).join(',') 
    : '';

    
    // Create filter object with both search and status
    const filters = {
      SearchValue: fields.SearchValue || '',
      StatusFilter: StatusFilterString,
      LobFilter: lobFilterString // Send as comma-separated string
    };
  
    this.datatableElement.dtInstance.then((dtInstance: any) => {
      dtInstance
        .column(0)
        .search(this.api.encryptText(JSON.stringify(filters)))
        .draw();
    });
  }

  get formcontrolsDataLeadForm() {
    return this.DataLeadForm.controls;
  }

  Get() {
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: "Bearer " + this.api.GetToken(),
      }),
    };
    const that = this;
    this.dtOptions = {
      pagingType: "full_numbers",
      pageLength: 10,
      serverSide: true,
      processing: true,
      ajax: (dataTablesParameters: any, callback) => {
        // Get current filter values
        const searchValue = that.searchForm.get('SearchValue').value;
        const statusFilter = that.searchForm.get('StatusFilter').value;
        const LobFilter = that.searchForm.get('LobFilter').value;
        
        // Add filters to the request URL
        let url = environment.apiUrl +
          "/DataDictionary/FetchAllData?User_Id=" +
          this.api.GetUserData("Id") +
          "&User_Type=" +
          this.api.GetUserType() +
          "&Unique_Id=" +
          this.uniqueId;
        
        if (searchValue) {
          url += "&SearchValue=" + encodeURIComponent(searchValue);
        }
        if (statusFilter) {
          url += "&StatusFilter=" + encodeURIComponent(statusFilter);
        }
        if (LobFilter) {
          url += "&LobFilter=" + encodeURIComponent(LobFilter);
        }
  
        that.http
          .post<DataTablesResponse>(
            this.api.additionParmsEnc(url),
            dataTablesParameters,
            httpOptions
          )
          .subscribe((res: any) => {
            var resp = JSON.parse(this.api.decryptText(res.response));
            if (resp.status === "urlWrong") {
              that.hasAccess = false;
              that.errorMessage = resp.msg;
              return;
            }
            that.hasAccess = true;
            that.dataAr = resp.data;
            callback({
              recordsTotal: resp.recordsTotal,
              recordsFiltered: resp.recordsFiltered,
              data: [],
            });
          });
      },
    };
  }

  loadDropdownData() {
    this.lobTypesData = [
      { Id: 'Motor', Name: 'Motor' },
      { Id: 'Health', Name: 'Health' },
      { Id: 'PA', Name: 'PA' },
      { Id: 'Life', Name: 'Life' },
      { Id: 'Other', Name: 'Other' },
    ];

    this.MotorTypesData = [
      { Id: 'Private Car', Name: 'Private Car' },
      { Id: 'Two Wheeler', Name: 'Two Wheeler' },
      { Id: 'PCV', Name: 'PCV' },
      { Id: 'GCV', Name: 'GCV' },
      { Id: 'MISCD', Name: 'MISCD' },
    ];

    this.ClaimData = [
      { Id: 'Yes', Name: 'Yes' },
      { Id: 'No', Name: 'No' },
    ];

    this.StausData = [
      { Id: '1', Name: 'Uploaded' },
      { Id: '0', Name: 'Failed' },
    ];
  }

  setupLobTypeListener() {

    // console.log('Data Lead Form Data in edit Form : ',this.DataLeadForm.value);
    this.DataLeadForm.get('LobType').valueChanges.subscribe((selectedArray) => {
      const selectedLob = selectedArray.length ? selectedArray[0] : null;
      this.updateFieldVisibility(selectedLob.Name);
      // alert(selectedLob.Name);
      if (selectedLob.Name === 'Health') {
        this.showHealthFields = true;
        this.showMotorFields = false;
        this.setMotorValidators(false);
      }else if(selectedLob.Name === 'PA') {
        this.showHealthFields = true;
        this.showMotorFields = false;
        this.setMotorValidators(false);
      }else if(selectedLob.Name === 'Life') {
        this.showHealthFields = true;
        this.showMotorFields = false;
        this.setMotorValidators(false);
      }else if(selectedLob.Name === 'Other') {
        this.showHealthFields = true;
        this.showMotorFields = false;
        this.setMotorValidators(false);
      }
      else if (selectedLob.Name === 'Motor') {
        this.showHealthFields = false;
        this.showMotorFields = true;
        this.setMotorValidators(true);
      }
      else {
        this.showHealthFields = false;
        this.showMotorFields = false;
        this.setMotorValidators(false);
      }
    });
  }

  setMotorValidators(isRequired: boolean) {
      const motorFields = [
        'MotorType', 
        'RegistrationNo', 
        'Make', 
        'Model', 
        'Variant', 
        'PrevPolicyInsurer', 
        'Claim'
      ];
      
      motorFields.forEach(field => {
        const control = this.DataLeadForm.get(field);
        if (isRequired) {
          control.setValidators(Validators.required);
        } else {
          control.clearValidators();
        }
        control.updateValueAndValidity();
      });
    }

    // Method to open modal in edit mode
    openEditModal(rowId: string) {

      this.modalMode = 'edit';
      
      this.currentEditId = rowId;
    
      const formData = new FormData();
      formData.append("Edit_id", rowId);
      
      this.api.HttpPostType("DataDictionary/EditData", formData).then(
        (resp: any) => {
          if (resp.status) {
            const rowData = resp.data;
            
            // Reset form and visibility flags
            this.ResetForm();

            
            
            
            // Patch the values to the form
            this.DataLeadForm.patchValue({
              LobType: rowData.LobType ? [{ Id: rowData.LobType, Name: rowData.LobType }] : [],
              Name: rowData.Name || '',
              Mobile: rowData.Mobile || '',
              Email: rowData.Email || '',
              State: rowData.State || '',
              City: rowData.City || '',
              Pincode: rowData.Pincode || '',
              Source: rowData.Source || '',
              Campaign: rowData.Campaign || '',
              StartDate: rowData.StartDate || '',
              ExpiryDate: rowData.ExpiryDate || '',
              Insurer: rowData.Insurer || '',
              Premium: rowData.Premium || '',
              FamilyGroup: rowData.FamilyGroup || '',
              MotorType: rowData.MotorType ? [{ Id: rowData.MotorType, Name: rowData.MotorType }] : [],
              RegistrationNo: rowData.RegistrationNo || '',
              Make: rowData.Make || '',
              Model: rowData.Model || '',
              Variant: rowData.Variant || '',
              PrevPolicyInsurer: rowData.PrevPolicyInsurer || '',
              Claim: rowData.Claim ? [{ Id: rowData.Claim, Name: rowData.Claim }] : []
            });
    
            // Show/hide fields based on LobType
            this.showMotorFields = rowData.LobType === 'Motor';
            this.showHealthFields = rowData.LobType === 'Health';
            
            // Common fields will always be visible

            this.updateFieldVisibility(rowData.LobType);

            this.setupLobTypeListener();
            
            $('#addDataLead').modal('show');
            
            
          } else {
            this.api.Toast("Error", "Failed to load data");
          }
          this.api.HideLoading();
        },
        (err) => {
          this.api.HideLoading();
          console.error("Error fetching data:", err);
          this.api.Toast("Error", "Failed to load data");
        }
      );
    }

    updateFieldVisibility(lobType: string) {
      switch(lobType) {
        case 'Health':
        case 'PA':
        case 'Life':
        case 'Other':
          this.showHealthFields = true;
          this.showMotorFields = false;
          this.setMotorValidators(false);
          break;
        case 'Motor':
          this.showHealthFields = false;
          this.showMotorFields = true;
          this.setMotorValidators(true);
          break;
        default:
          this.showHealthFields = false;
          this.showMotorFields = false;
          this.setMotorValidators(false);
      }
    }
    
    ResetForm() {
      this.DataLeadForm.reset();
      this.showMotorFields = false;
      this.showHealthFields = false;
    }


    onSubmit() {

      this.SubmitDataLeadForm = true;
      
      if (this.DataLeadForm.invalid) {
        return;
      }
    
      const formValues = this.DataLeadForm.value;
      const formData = new FormData();

      formData.append("Edit_Id", this.currentEditId);
      formData.append("unique_id", this.uniqueId);
    
      // Append user data
      formData.append("User_Id", this.api.GetUserData("Id"));
      formData.append("User_Type", this.api.GetUserType());
    
      // Append common fields
      formData.append("LobType", formValues.LobType[0].Name);
      formData.append("Name", formValues.Name);
      formData.append("Mobile", formValues.Mobile);
      formData.append("Email", formValues.Email || '');
      formData.append("State", formValues.State || '');
      formData.append("City", formValues.City || '');
      formData.append("Pincode", formValues.Pincode || '');
      formData.append("Source", formValues.Source || '');
      formData.append("Campaign", formValues.Campaign || '');
      formData.append("StartDate", formValues.StartDate || '');
      formData.append("ExpiryDate", formValues.ExpiryDate);
    
      // Append Motor specific fields if Motor is selected
      if (this.showMotorFields) {
        formData.append("MotorType", formValues.MotorType[0].Name || '');
        formData.append("RegistrationNo", formValues.RegistrationNo);
        formData.append("Make", formValues.Make);
        formData.append("Model", formValues.Model);
        formData.append("Variant", formValues.Variant);
        formData.append("PrevPolicyInsurer", formValues.PrevPolicyInsurer);
        formData.append("Claim", formValues.Claim[0].Name || '');
      }
    
      // Append Health specific fields if Health is selected
      if (this.showHealthFields) {
        formData.append("Insurer", formValues.Insurer || '');
        formData.append("Premium", formValues.Premium || '');
        formData.append("FamilyGroup", formValues.FamilyGroup || '');
      }
    
      this.api.IsLoading();
      

      
      // Determine the API endpoint based on mode
      const endpoint = 'DataDictionary/update';
    
      this.api.HttpPostType(endpoint, formData).then(
        (resp: any) => {
          if (resp.status == false) {
            this.api.Toast("Warning", resp.msg);
          } else {
            this.api.Toast("Success", resp.msg);
            this.Reload();
            this.Get();
            // Close the modal and reset
            
            $('#addDataLead').modal('hide');
          }
          this.api.HideLoading();
        },
        (err) => {
          this.api.HideLoading();
          console.error("Error submitting data:", err);
          this.api.Toast("Error", "Failed to submit data");
        }
      );
    }

    addForm() {
      

      this.modalMode = 'add';
      this.currentEditId = '';

      this.setupLobTypeListener();
      
      $('#addDataLead').modal('show');
    }

    






}
