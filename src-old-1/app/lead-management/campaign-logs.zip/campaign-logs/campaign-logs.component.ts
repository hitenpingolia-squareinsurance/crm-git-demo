
import {PolicyWiseDetailsAgentComponent} from "../policy-wise-details-agent/policy-wise-details-agent.component";

import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Component, OnInit, ViewChild, Inject, Optional } from "@angular/core";
import { ApiService } from "../../providers/api.service";
import { Router } from "@angular/router";
import { environment } from "../../../environments/environment";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from "@angular/material/dialog";
import { DataTableDirective } from "angular-datatables";
import { trim } from "jquery";


@Component({
  selector: 'app-campaign-logs',
  templateUrl: './campaign-logs.component.html',
  styleUrls: ['./campaign-logs.component.css']
})



class ColumnsObj {
  SrNo: string;
  Id: string;
  campaign_name: string;
  requesterName: string;
  requesterCode: string;
  campaign_for: string;
  lob: string;
  state: string;
  city: string;
  status: string;
  requester_remark: string;
}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
}



export class CampaignLogsComponent implements OnInit {

  Id: any;


  @ViewChild(DataTableDirective, { static: false })
  datatableElement: DataTableDirective;

  dtOptions: DataTables.Settings = {};
  dataAr: any[];
  DataAr: any[];


  // ClaimData: any;
  // row: any;
  campaignData: any;
  leadData: any;
  count: any;
  urlSegment: string;

  constructor(
    public api: ApiService,
    private route: Router,
    private formBuilder: FormBuilder,
    private http: HttpClient,
    public dialog: MatDialog,
  ) {


    console.log(this.route.url);

    var splitted = this.route.url.split("/");
    if (typeof splitted[1] != "undefined") {
      this.urlSegment = splitted[3];
    }

   this.Id = this.urlSegment;
  } 

  ngOnInit() {
    this.GetCampaignDetails(this.Id);
  }

  GetCampaignDetails(Id) {
    const formData = new FormData();
    formData.append("Id", Id);

    this.api.IsLoading();
    this.api.HttpPostType("Campaign/CampaignDetails", formData).then(
      (result) => {
        this.api.HideLoading();
        if (result["status"] == true) {
          this.leadData = result["leadData"];
          this.campaignData = result["campaignData"];
          this.count = result["count"];
          console.log(this.leadData);
          // console.log(this.campaignData.campaign_name);
          // console.log(this.count.Total);

        } else {
          this.api.Toast("Warning", result["Message"]);
        }
      },
      (err) => {
        this.api.HideLoading();
        this.api.Toast(
          "Warning",
          "Network Error : " + err.name + "(" + err.statusText + ")"
        );
      }
    );
  }




    ClearSearch() {
      this.dataAr = [];
      // this.RequestData.reset();
      this.ResetDT();
    }
  
    Reload() {
      this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
        dtInstance.draw();
      });
    }
  
    ResetDT() {
      this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
        dtInstance.search("").column(0).search("").draw();
      });
    }
  
    SearchData() {
      this.dataAr = [];
      this.datatableElement.dtInstance.then((dtInstance: any) => {
        // var fields = this.RequestData.value;
  
        // var Quote_Type = fields["Request_type"];
        // var Search = fields["SearchVal"];
  
        // if (Quote_Type != "" && Quote_Type != null) {
        //   Quote_Type = fields["Request_type"][0]["Id"];
        // }
  
        // var query = {
        //   QuoteType: trim(Quote_Type),
        //   Search: trim(Search),
        // };
  
        dtInstance
          .column(0)
          .search(this.api.encryptText(JSON.stringify('')))
          .draw();
        this.Get();
      });
    }
  




      Get() {
        const that = this;
    
        this.dtOptions = {
          pagingType: "full_numbers",
          pageLength: 10,
          serverSide: true,
          processing: true,
          ajax: (dataTablesParameters: any, callback) => {
            that.http
              .post<DataTablesResponse>(
                this.api.additionParmsEnc(
                  environment.apiUrl +
                    "/Campaign/View_request?User_Id=" +
                    this.api.GetUserData("Id") +
                    "&User_Type=" +
                    this.api.GetUserType() +
                    "&urlSegment=" +
                    this.urlSegment
                ),
                dataTablesParameters,
                this.api.getHeader(environment.apiUrl)
              )
              .subscribe((res: any) => {
                this.api.HideLoading();
                var resp = JSON.parse(this.api.decryptText(res.response));
    
                that.dataAr = resp.data;
            
              
                if (that.dataAr.length > 0) {
                }
                callback({
                  recordsTotal: resp.recordsTotal,
                  recordsFiltered: resp.recordsFiltered,
                  data: [],
                });
              });
          },
        };
      }
    

      
  AgentBusiness(id: any) {
    const dialogRef = this.dialog.open(PolicyWiseDetailsAgentComponent, {
      width: "60%",
      height: "70%",
      disableClose: false,
      data: { id: id },
    });

    dialogRef.afterClosed().subscribe((result:any) => {
      // this.Reload();
    });
  }

}

