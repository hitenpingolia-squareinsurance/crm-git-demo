import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestVisitingCardComponent } from './request-visiting-card.component';

describe('RequestVisitingCardComponent', () => {
  let component: RequestVisitingCardComponent;
  let fixture: ComponentFixture<RequestVisitingCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequestVisitingCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestVisitingCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
