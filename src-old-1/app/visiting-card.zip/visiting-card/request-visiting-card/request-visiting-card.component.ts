import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-visiting-card',
  templateUrl: './request-visiting-card.component.html',
  styleUrls: ['./request-visiting-card.component.css']
})
export class RequestVisitingCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
